REPLAY status=1 minors=4680 facts=6733 f=-990265381626 eqv=3.928e-09 inv=0.000e+00 boxv=1.602e-13 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=720 deferred=0 undec=25 dep_tests=4994 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=1 minors=4680 facts=4570 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=378 deferred=1 undec=3 maxiter=4680
