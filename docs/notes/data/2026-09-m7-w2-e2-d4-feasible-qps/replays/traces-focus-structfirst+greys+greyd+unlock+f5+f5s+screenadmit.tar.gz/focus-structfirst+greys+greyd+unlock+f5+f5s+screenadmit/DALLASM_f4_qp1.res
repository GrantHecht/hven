REPLAY status=3 minors=534 facts=1048 f=-896522.371782 eqv=1.531e+00 inv=0.000e+00 boxv=1.476e-10 blk_term=0 cert=0 cert_rej=0 zmcap=1 zmexh=0 retreats=0 exch=43 deferred=213 undec=0 dep_tests=375 entry_rm=0 recheck_rm=212 untested=0 k0_reused=0
DUMPED result status=3 minors=194 facts=370 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=128 deferred=0 undec=0 maxiter=2150
