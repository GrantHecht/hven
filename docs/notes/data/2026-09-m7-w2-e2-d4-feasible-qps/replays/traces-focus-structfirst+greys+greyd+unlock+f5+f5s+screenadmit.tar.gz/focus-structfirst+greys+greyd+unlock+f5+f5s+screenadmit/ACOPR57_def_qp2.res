REPLAY status=3 minors=883 facts=34 f=766.741512794 eqv=9.066e-08 inv=1.081e-01 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=1 zmexh=0 retreats=0 exch=55 deferred=381 undec=0 dep_tests=437 entry_rm=43 recheck_rm=400 untested=425 k0_reused=0
DUMPED result status=3 minors=47 facts=4 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=2 deferred=0 undec=0 maxiter=2080
