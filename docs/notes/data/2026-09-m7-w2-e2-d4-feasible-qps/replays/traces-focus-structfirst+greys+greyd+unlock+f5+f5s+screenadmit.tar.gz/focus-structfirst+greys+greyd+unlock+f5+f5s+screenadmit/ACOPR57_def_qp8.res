REPLAY status=3 minors=8 facts=15 f=2.39483291651e-10 eqv=1.871e-01 inv=1.887e-02 boxv=0.000e+00 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=1 undec=2 dep_tests=7 entry_rm=0 recheck_rm=1 untested=0 k0_reused=0
DUMPED result status=3 minors=35 facts=40 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=14 deferred=0 undec=0 maxiter=7100
