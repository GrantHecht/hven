REPLAY status=0 minors=748 facts=766 f=664247.80146 eqv=3.680e-13 inv=0.000e+00 boxv=4.441e-16 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=495 deferred=0 undec=0 dep_tests=738 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=594 facts=595 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=359 deferred=0 undec=0 maxiter=9000
