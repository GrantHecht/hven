REPLAY status=0 minors=658 facts=1216 f=1974445.19088 eqv=4.547e-13 inv=0.000e+00 boxv=1.494e-13 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=114 deferred=0 undec=0 dep_tests=547 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=908 facts=990 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=1 retreats=0 exch=119 deferred=1 undec=1 maxiter=4920
