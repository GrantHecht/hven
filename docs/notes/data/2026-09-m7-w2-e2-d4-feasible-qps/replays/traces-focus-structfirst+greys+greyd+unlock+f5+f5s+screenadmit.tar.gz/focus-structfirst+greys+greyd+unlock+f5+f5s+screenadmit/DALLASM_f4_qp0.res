REPLAY status=3 minors=746 facts=1 f=-911961.358133 eqv=1.520e+00 inv=0.000e+00 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=1 zmexh=0 retreats=0 exch=349 deferred=175 undec=0 dep_tests=1152 entry_rm=0 recheck_rm=175 untested=0 k0_reused=0
DUMPED result status=3 minors=64 facts=2 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=16 deferred=0 undec=0 maxiter=1960
