REPLAY status=1 minors=4680 facts=8098 f=-nan eqv=nan inv=0.000e+00 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=2978 deferred=1 undec=9 dep_tests=3380 entry_rm=3 recheck_rm=1 untested=0 k0_reused=0
DUMPED result status=3 minors=1222 facts=1230 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=1107 deferred=0 undec=1 maxiter=4680
