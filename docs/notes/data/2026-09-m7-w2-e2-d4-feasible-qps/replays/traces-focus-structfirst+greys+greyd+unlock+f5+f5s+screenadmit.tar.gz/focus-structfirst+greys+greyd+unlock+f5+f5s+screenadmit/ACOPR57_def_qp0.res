REPLAY status=0 minors=207 facts=67 f=432.660936979 eqv=6.144e-07 inv=3.071e-07 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=71 deferred=0 undec=0 dep_tests=83 entry_rm=49 recheck_rm=35 untested=53 k0_reused=0
DUMPED result status=3 minors=51 facts=31 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=0 deferred=0 undec=0 maxiter=2080
