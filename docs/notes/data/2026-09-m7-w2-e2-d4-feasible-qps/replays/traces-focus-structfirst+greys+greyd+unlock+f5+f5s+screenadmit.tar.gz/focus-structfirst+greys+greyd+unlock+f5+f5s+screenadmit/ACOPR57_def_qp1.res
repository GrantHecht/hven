REPLAY status=0 minors=156 facts=30 f=501.804570752 eqv=2.542e-08 inv=1.663e-08 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=55 deferred=0 undec=0 dep_tests=60 entry_rm=43 recheck_rm=23 untested=61 k0_reused=0
DUMPED result status=3 minors=90 facts=16 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=19 deferred=0 undec=0 maxiter=2080
