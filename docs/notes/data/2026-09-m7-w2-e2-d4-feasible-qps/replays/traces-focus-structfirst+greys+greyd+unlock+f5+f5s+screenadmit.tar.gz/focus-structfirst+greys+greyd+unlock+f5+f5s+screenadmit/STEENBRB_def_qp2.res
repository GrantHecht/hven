REPLAY status=1 minors=4680 facts=4736 f=-nan eqv=nan inv=0.000e+00 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=62 deferred=0 undec=2 dep_tests=188 entry_rm=3 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=1 minors=4680 facts=4695 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=881 deferred=2 undec=5 maxiter=4680
