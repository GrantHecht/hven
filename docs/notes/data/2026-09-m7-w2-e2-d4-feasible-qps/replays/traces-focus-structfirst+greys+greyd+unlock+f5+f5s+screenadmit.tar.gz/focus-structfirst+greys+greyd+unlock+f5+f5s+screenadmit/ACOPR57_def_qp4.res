REPLAY status=0 minors=400 facts=578 f=-18.3950535429 eqv=2.651e-15 inv=7.459e-17 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 dep_tests=217 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=27 facts=126 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=6 deferred=0 undec=0 maxiter=7100
