REPLAY status=0 minors=737 facts=794 f=1964037.12937 eqv=9.477e-13 inv=0.000e+00 boxv=1.895e-12 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=460 deferred=4 undec=0 dep_tests=722 entry_rm=0 recheck_rm=4 untested=0 k0_reused=0
DUMPED result status=3 minors=242 facts=247 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 maxiter=5080
