REPLAY status=3 minors=1222 facts=1230 f=-nan eqv=nan inv=0.000e+00 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=1107 deferred=0 undec=1 dep_tests=1307 entry_rm=3 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=1222 facts=1230 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=1107 deferred=0 undec=1 maxiter=4680
