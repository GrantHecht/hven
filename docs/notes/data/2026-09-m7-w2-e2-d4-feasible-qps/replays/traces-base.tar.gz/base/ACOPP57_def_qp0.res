REPLAY status=3 minors=2 facts=1 f=0.242644830788 eqv=4.032e-07 inv=0.000e+00 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 dep_tests=11 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=2 facts=1 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 maxiter=1795
