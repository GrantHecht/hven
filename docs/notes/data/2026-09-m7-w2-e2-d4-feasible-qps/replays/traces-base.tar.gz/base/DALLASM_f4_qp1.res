REPLAY status=3 minors=194 facts=370 f=-918557.804974 eqv=1.509e+00 inv=0.000e+00 boxv=6.661e-15 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=128 deferred=0 undec=0 dep_tests=275 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=194 facts=370 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=128 deferred=0 undec=0 maxiter=2150
