REPLAY status=3 minors=242 facts=247 f=-188.6 eqv=1.612e+03 inv=0.000e+00 boxv=0.000e+00 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 dep_tests=953 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=242 facts=247 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 maxiter=5080
