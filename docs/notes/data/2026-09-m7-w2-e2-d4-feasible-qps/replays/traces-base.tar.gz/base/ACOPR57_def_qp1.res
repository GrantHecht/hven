REPLAY status=3 minors=90 facts=16 f=634.431679307 eqv=2.334e-06 inv=1.418e-01 boxv=0.000e+00 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=19 deferred=0 undec=0 dep_tests=21 entry_rm=43 recheck_rm=23 untested=61 k0_reused=0
DUMPED result status=3 minors=90 facts=16 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=19 deferred=0 undec=0 maxiter=2080
