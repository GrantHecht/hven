REPLAY status=3 minors=908 facts=990 f=1974601.34679 eqv=4.547e-13 inv=0.000e+00 boxv=6.273e-15 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=1 retreats=0 exch=119 deferred=1 undec=1 dep_tests=822 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=908 facts=990 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=1 retreats=0 exch=119 deferred=1 undec=1 maxiter=4920
