REPLAY status=3 minors=6 facts=10 f=-77.5858516283 eqv=3.456e+00 inv=0.000e+00 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=1 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 dep_tests=6 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=6 facts=10 blk_term=0 cert=0 cert_rej=1 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=1 undec=1 maxiter=6830
