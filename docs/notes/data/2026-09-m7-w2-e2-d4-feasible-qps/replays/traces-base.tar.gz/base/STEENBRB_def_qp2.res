REPLAY status=1 minors=4680 facts=4695 f=-990507753116 eqv=9.685e-09 inv=0.000e+00 boxv=3.498e-13 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=881 deferred=2 undec=5 dep_tests=4378 entry_rm=3 recheck_rm=1 untested=0 k0_reused=0
DUMPED result status=1 minors=4680 facts=4695 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=881 deferred=2 undec=5 maxiter=4680
