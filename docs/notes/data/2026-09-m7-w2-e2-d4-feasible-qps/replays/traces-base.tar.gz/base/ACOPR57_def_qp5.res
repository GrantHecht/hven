REPLAY status=1 minors=7100 facts=7101 f=4.4805033313e-09 eqv=3.354e-12 inv=8.497e-15 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 dep_tests=2663 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=1 minors=7100 facts=7101 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=0 deferred=0 undec=0 maxiter=7100
