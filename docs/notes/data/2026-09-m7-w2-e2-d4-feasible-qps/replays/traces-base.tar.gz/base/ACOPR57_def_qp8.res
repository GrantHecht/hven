REPLAY status=3 minors=35 facts=40 f=0.0192203501279 eqv=5.213e-16 inv=3.469e-18 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=14 deferred=0 undec=0 dep_tests=25 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=35 facts=40 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=14 deferred=0 undec=0 maxiter=7100
