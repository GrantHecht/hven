REPLAY status=3 minors=594 facts=595 f=21565.8126714 eqv=3.592e+03 inv=0.000e+00 boxv=0.000e+00 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=359 deferred=0 undec=0 dep_tests=594 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=594 facts=595 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=359 deferred=0 undec=0 maxiter=9000
