REPLAY status=3 minors=47 facts=4 f=0 eqv=4.066e+00 inv=8.508e-01 boxv=0.000e+00 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=2 deferred=0 undec=0 dep_tests=4 entry_rm=43 recheck_rm=0 untested=43 k0_reused=0
DUMPED result status=3 minors=47 facts=4 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=2 deferred=0 undec=0 maxiter=2080
