REPLAY status=1 minors=7100 facts=7103 f=2.43323010445e-09 eqv=4.202e-16 inv=7.980e-17 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=34 deferred=0 undec=0 dep_tests=2407 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=1 minors=7100 facts=7103 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=34 deferred=0 undec=0 maxiter=7100
