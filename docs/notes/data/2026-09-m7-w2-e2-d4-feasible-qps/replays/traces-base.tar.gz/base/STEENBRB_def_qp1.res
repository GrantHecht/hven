REPLAY status=1 minors=4680 facts=4570 f=-990641581607 eqv=8.009e-07 inv=0.000e+00 boxv=9.819e-10 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=378 deferred=1 undec=3 dep_tests=4752 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=1 minors=4680 facts=4570 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=378 deferred=1 undec=3 maxiter=4680
