REPLAY status=3 minors=64 facts=2 f=-905709.825069 eqv=1.526e+00 inv=0.000e+00 boxv=3.031e-13 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=16 deferred=0 undec=0 dep_tests=80 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=64 facts=2 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=1 exch=16 deferred=0 undec=0 maxiter=1960
