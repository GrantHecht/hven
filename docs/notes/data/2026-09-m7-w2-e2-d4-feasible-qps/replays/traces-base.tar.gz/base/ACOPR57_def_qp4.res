REPLAY status=3 minors=27 facts=126 f=-158.198311811 eqv=5.976e+01 inv=4.801e-01 boxv=0.000e+00 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=6 deferred=0 undec=0 dep_tests=104 entry_rm=0 recheck_rm=1 untested=0 k0_reused=0
DUMPED result status=3 minors=27 facts=126 blk_term=1 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=6 deferred=0 undec=0 maxiter=7100
