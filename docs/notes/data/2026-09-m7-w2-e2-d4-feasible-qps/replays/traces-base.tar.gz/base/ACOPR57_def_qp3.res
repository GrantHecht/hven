REPLAY status=1 minors=4360 facts=4361 f=1352734499.6 eqv=5.837e-05 inv=3.029e-05 boxv=0.000e+00 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=1869 deferred=0 undec=0 dep_tests=2492 entry_rm=0 recheck_rm=622 untested=0 k0_reused=0
DUMPED result status=1 minors=4360 facts=4360 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=0 retreats=0 exch=1869 deferred=0 undec=0 maxiter=4360
