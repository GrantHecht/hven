REPLAY status=3 minors=10 facts=4 f=0.00109761008774 eqv=9.694e-09 inv=0.000e+00 boxv=5.319e-08 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=1 retreats=0 exch=0 deferred=0 undec=0 dep_tests=4 entry_rm=0 recheck_rm=0 untested=0 k0_reused=0
DUMPED result status=3 minors=10 facts=4 blk_term=0 cert=0 cert_rej=0 zmcap=0 zmexh=1 retreats=0 exch=0 deferred=0 undec=0 maxiter=1795
